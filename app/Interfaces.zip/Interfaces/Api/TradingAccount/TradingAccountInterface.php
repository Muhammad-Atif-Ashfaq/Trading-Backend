<?php

namespace App\Interfaces\Api\TradingAccount;

interface TradingAccountInterface
{
    /**
     * TODO: Create a trading account.
     *
     * @param array $data
     * @return mixed
     */
    public function createTradingAccount(array $data);
}
