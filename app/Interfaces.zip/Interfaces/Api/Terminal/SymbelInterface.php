<?php

namespace App\Interfaces\Api\Terminal;

interface SymbelInterface
{
    /**
     * TODO: Get all symbols.
     *
     * @return mixed
     */
    public function getAllSymbels();
}
