<?php

namespace App\Interfaces\Api\Config;


interface ConfigInterface
{

   
    public function getConfigDataFeeds();

}
